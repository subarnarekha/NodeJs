var app = angular.module("myApp", ["ngRoute"]);
app.config(function ($routeProvider) {
    $routeProvider
        .when("/", {
            templateUrl: "/showall"
        })
        .when("/show", {
            templateUrl: "<h1>hello</h1>"
        })
        .when("/adddetails", {
            templateUrl: "/add"
        })
        .when("/blue", {
            templateUrl: "blue.htm"
        });
});
app.controller('employeeCtrl', function ($scope, $http) {
    console.log("before show all");
    $scope.users = [];
    $http.get("/details")
        .then(function (response) {
            $scope.users = response.data;
        }, function (err) {
            console.log(err);
        }
        );
    console.log("at show all");
});
app.controller('myCtrl', function($scope,$http) {
       console.log("hello");
   });
